package praktikum_hmm_BAB_II;
import java.util.Scanner;
public class Lembur_kerja {
    public static void main(String[]args){
Scanner input = new Scanner(System.in);
int perjam,jam,upah,jamlembur,jamkurang,upahlembur,denda,total;
System.out.print("Jam Kerja     = ");
jam = input.nextInt();
        if(jam>60){
            jamlembur = jam-60;
            upah = 60*5000;
            upahlembur = jamlembur*6000;
            denda = 0;            
            total = upah+upahlembur;
            System.out.println("Upah          = Rp. " + upah);
            System.out.println("Lembur        = Rp. " + upahlembur);
            System.out.println("Denda         = Rp. " + denda);
            System.out.println("=======================");
            System.out.println("Total         = Rp. " + total);}
        else if(jam<50){
            jamkurang = 50-jam;
            upah = jam*5000;
            upahlembur = 0;
            denda = jamkurang*1000;            
            total = upah-denda;
            System.out.println("Upah          = Rp. " + upah);
            System.out.println("Lembur        = Rp. " + upahlembur);
            System.out.println("Denda         = Rp. " + denda);
            System.out.println("=======================");
            System.out.println("Total         = Rp. " + total);}
         else { 
            jamlembur = 0;
            upah = jam*5000;
            upahlembur = jamlembur*6000;
            denda = 0;            
            total = upah+upahlembur;
            System.out.println("Upah          = Rp. " + upah);
            System.out.println("Lembur        = Rp. " + upahlembur);
            System.out.println("Denda         = Rp. " + denda);
            System.out.println("=======================");
            System.out.println("Total         = Rp. " + total);
                    }
                }
    }    

